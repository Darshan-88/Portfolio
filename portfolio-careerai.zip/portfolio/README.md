# Portfolio

A personal developer portfolio built with React 19, Vite, and Tailwind CSS 4.

Built during the placement training program at [TAP Academy](https://thetapacademy.com/) (full-stack development, AI and augmented reality training).

## Features
- Single-page React application
- Tailwind CSS v4 styling
- Framer Motion animations and AOS scroll effects
- Contact form integration with EmailJS
- Responsive modern dark aesthetic

## Getting Started

```bash
# Install dependencies
npm install

# Start development server
npm run dev

# Run linter
npm run lint

# Build for production
npm run build
```

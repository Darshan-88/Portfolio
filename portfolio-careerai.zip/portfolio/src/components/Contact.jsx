import { useRef, useState } from 'react'
import { motion, useScroll, useTransform } from 'framer-motion'
import { emailjsConfig, personalInfo, socialLinks } from '../data/portfolioData'

export default function Contact() {
  const ref = useRef(null)
  const formRef = useRef(null)
  const [status, setStatus] = useState('idle') // 'idle' | 'sending' | 'success' | 'error'

  const [feedback, setFeedback] = useState('')

  const { scrollYProgress } = useScroll({
    target: ref,
    offset: ['start end', 'end start'],
  })

  const y = useTransform(scrollYProgress, [0, 1], ['-20%', '30%'])

  const handleSubmit = async (e) => {
    e.preventDefault()
    if (status === 'sending') return

    const form = formRef.current
    const fields = new FormData(form)
    setFeedback('')
    if (!['first_name', 'user_email', 'message'].every(key => String(fields.get(key) || '').trim())) {
      setFeedback('Enter your name, email and message.')
      return
    }
    const { serviceId, templateId, publicKey } = emailjsConfig
    if (!serviceId || !templateId || !publicKey) {
      setFeedback('The contact form is missing its EmailJS settings. Please use the direct email link.')
      return
    }
    fields.set('service_id', serviceId)
    fields.set('template_id', templateId)
    fields.set('user_id', publicKey)
    setStatus('sending')
    const controller = new AbortController()
    const timeout = setTimeout(() => controller.abort(), 15000)
    try {
      const response = await fetch('https://api.emailjs.com/api/v1.0/email/send-form', {
        method: 'POST', body: fields, signal: controller.signal,
      })
      if (!response.ok) {
        setFeedback(`EmailJS declined the request (HTTP ${response.status}). Your message is still here. You can also use the direct email link.`)
        return
      }
      form.reset()
      setFeedback('EmailJS accepted your message. Thank you for getting in touch.')
    } catch {
      setFeedback(controller.signal.aborted
        ? 'The request timed out. Delivery is unconfirmed. Your message is still here.'
        : 'Could not reach EmailJS. Check your connection or use the direct email link.')
    } finally {
      clearTimeout(timeout)
      setStatus('idle')
    }
  }

  return (
    <section
      ref={ref}
      id="contact"
      className="bg-[#0a0a0a] w-full min-h-screen relative overflow-hidden flex items-end pt-32 border-t border-gray-900"
    >
      {/* Background Parallax Typography */}
      <motion.div
        style={{ y }}
        className="absolute inset-0 pointer-events-none z-0 flex items-center justify-center"
      >
        <div
          className="text-[25vw] leading-[0.75] font-black uppercase tracking-tighter select-none scale-y-[1.6] origin-top text-white/5"
          style={{ fontFamily: "'Impact', 'Arial Black', sans-serif" }}
        >
          CONTACT
        </div>
      </motion.div>

      {/* Foreground Red Card */}
      <div
        data-aos="fade-up"
        className="relative z-10 w-full md:w-[85%] lg:w-[75%] ml-auto bg-[#ff2a2a] p-8 md:p-16 rounded-tl-3xl shadow-2xl"
      >
        {/* Header row */}
        <div className="flex items-center justify-between gap-4 mb-12">
          <span className="text-xs uppercase font-bold tracking-[0.2em] text-white/80">
            Reach Me
          </span>
          {socialLinks.instagram ? (
            <a
              href={socialLinks.instagram}
              target="_blank"
              rel="noopener noreferrer"
              className="px-4 py-1.5 rounded-full bg-black/20 border border-white/20 text-white text-xs font-semibold hover:bg-black/40 transition-colors"
            >
              DM on Instagram
            </a>
          ) : (
            <a
              href="https://instagram.com"
              target="_blank"
              rel="noopener noreferrer"
              className="px-4 py-1.5 rounded-full bg-black/20 border border-white/20 text-white text-xs font-semibold hover:bg-black/40 transition-colors"
            >
              DM on Instagram
            </a>
          )}
        </div>

        {/* Form */}
        <form
          ref={formRef}
          onSubmit={handleSubmit}
          className="flex flex-col gap-10"
        >
          {/* Two-column layout on md+ */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 md:gap-12">
            {/* Left Inputs */}
            <div className="flex flex-col gap-8">
              <input
                id="firstName"
                name="first_name"
                required
                placeholder="First Name *"
                className="bg-transparent border-b border-white/40 pb-3 text-lg placeholder-white/80 text-white focus:outline-none focus:border-white transition-colors"
              />
              <input
                id="lastName"
                name="last_name"
                placeholder="Last Name"
                className="bg-transparent border-b border-white/40 pb-3 text-lg placeholder-white/80 text-white focus:outline-none focus:border-white transition-colors"
              />
              <input
                id="email"
                name="user_email"
                type="email"
                required
                placeholder="Your Email *"
                className="bg-transparent border-b border-white/40 pb-3 text-lg placeholder-white/80 text-white focus:outline-none focus:border-white transition-colors"
              />
            </div>

            {/* Right Textarea */}
            <div className="flex flex-col">
              <textarea
                id="message"
                name="message"
                required
                placeholder="Your Message *"
                className="w-full h-full bg-transparent border-b border-white/40 pb-3 text-lg placeholder-white/80 text-white focus:outline-none focus:border-white transition-colors resize-none min-h-[140px]"
              />
            </div>
          </div>

          {/* Bottom Area */}
          <div className="flex flex-col gap-6 pt-4 border-t border-white/10">
            {/* Permission Checkbox */}
            <div className="flex items-center space-x-3 text-sm text-white/90">
              <input
                type="checkbox"
                id="consent"
                required
                className="w-4 h-4 rounded accent-black cursor-pointer"
              />
              <label htmlFor="consent" className="cursor-pointer select-none">
                I consent to being contacted regarding this inquiry.
              </label>
            </div>

            {/* Note */}
            <p className="text-xs text-white/70 leading-relaxed">
              Your message will be sent directly to my inbox. I typically respond within 24-48 hours.
            </p>

            {/* Direct Email Link */}
            <p className="text-xs text-white/85">
              For urgent inquiries, email directly:{' '}
              <a
                href={`mailto:${personalInfo.emails.primary}`}
                className="underline font-bold hover:text-black transition-colors"
              >
                {personalInfo.emails.primary}
              </a>
            </p>

            {/* Submit Button */}
            <div>
              {status === 'sending' && (
                <button
                  type="button"
                  disabled
                  className="inline-flex items-center gap-3 px-8 py-4 rounded-full bg-white/20 border border-white/30 text-white/70 font-bold cursor-wait"
                >
                  <svg
                    className="w-5 h-5 animate-spin text-white"
                    fill="none"
                    viewBox="0 0 24 24"
                  >
                    <circle
                      className="opacity-25"
                      cx="12"
                      cy="12"
                      r="10"
                      stroke="currentColor"
                      strokeWidth="4"
                    />
                    <path
                      className="opacity-75"
                      fill="currentColor"
                      d="M4 12a8 8 0 018-8v4a4 4 0 00-4 4H4z"
                    />
                  </svg>
                  <span>Sending...</span>
                </button>
              )}

              <p role="status" aria-live="polite">{feedback}</p>

              {status === 'idle' && (
                <button
                  type="submit"
                  className="group inline-flex items-center gap-3 px-8 py-4 rounded-full border border-white text-white font-bold hover:bg-white hover:text-[#ff2a2a] transition-all duration-300 w-fit cursor-pointer shadow-md"
                >
                  <span>Send Message</span>
                  <svg
                    className="w-4 h-4 transition-transform duration-300 group-hover:translate-x-1"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth={2}
                    viewBox="0 0 24 24"
                  >
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      d="M14 5l7 7m0 0l-7 7m7-7H3"
                    />
                  </svg>
                </button>
              )}
            </div>
          </div>
        </form>
      </div>
    </section>
  )
}

import { useState } from 'react'
import { careerDemo as demo } from '../data/portfolioData'

function skillsIn(text) {
  return demo.skills.filter(skill => {
    const literal = skill.replaceAll('.', '\\.')
    return new RegExp('(?<![\\p{L}\\p{N}_])' + literal + '(?![\\p{L}\\p{N}_])', 'iu').test(text)
  })
}

export default function CareerDemo() {
  const [resume, setResume] = useState(demo.resume)
  const [job, setJob] = useState(demo.job)
  const [result, setResult] = useState(null)
  function analyse(event) {
    event.preventDefault()
    const have = new Set(skillsIn(resume))
    const required = skillsIn(job)
    setResult({
      total: required.length,
      matched: required.filter(skill => have.has(skill)),
      missing: required.filter(skill => !have.has(skill)),
    })
  }
  const inputStyle = 'mt-2 block w-full resize-y rounded-xl border border-white/25 bg-black p-4 text-base font-normal text-white focus:border-red-400'
  return (
    <section id="career-demo" aria-labelledby="career-title" className="scroll-mt-16 bg-[#0a0a0a] px-6 py-20 text-white md:px-12">
      <div className="mx-auto max-w-6xl">
        <h2 id="career-title" className="text-4xl font-black tracking-tight md:text-6xl">{demo.title}</h2>
        <p className="my-5 max-w-2xl text-white/75">{demo.intro}</p>
        <form onSubmit={analyse} className="rounded-3xl border border-white/15 bg-[#151515] p-5 md:p-8">
          <div className="grid gap-5 md:grid-cols-2">
            <label className="font-semibold">Sample résumé<textarea required maxLength={20000} rows={4} className={inputStyle} value={resume} onChange={e => {setResume(e.target.value); setResult(null)}} /></label>
            <label className="font-semibold">Job description<textarea required maxLength={20000} rows={4} className={inputStyle} value={job} onChange={e => {setJob(e.target.value); setResult(null)}} /></label>
          </div>
          <button className="my-5 cursor-pointer rounded-full bg-white px-6 py-3 font-bold text-black transition-colors hover:bg-red-200">Analyse match</button>
          <p className="text-sm text-white/65">This sample runs in your browser. Your text stays on this device.</p>
          <div aria-live="polite">
            {result && <div className="mt-5 border-t border-white/15 pt-5">
              {result.total > 0 ? <>
                <strong className="text-3xl">{Math.round(result.matched.length / result.total * 100)}% skill match</strong>
                <p className="mt-2">{result.matched.length} of {result.total} recognised job skills appear in the résumé.</p>
                <p className="mt-3"><b>Matched skills</b> · {result.matched.join(', ') || 'None'}</p>
                <p><b>Missing skills</b> · {result.missing.join(', ') || 'None'}</p>
              </> : <p>No recognised job skills yet. Try adding Python, SQL or Docker to the job description.</p>}
            </div>}
          </div>
        </form>
        <details className="mt-6 border-b border-white/15 pb-5">
          <summary className="cursor-pointer font-semibold hover:text-red-300">How I built CareerAI</summary>
          <ol aria-label="Full application flow" className="my-4 flex flex-wrap gap-2">{demo.architecture.map((step, i) => <li key={step} className="rounded-lg bg-white/10 px-3 py-2 text-sm">{i+1}. {step}</li>)}</ol>
          <p className="max-w-3xl text-white/75">{demo.decision}</p>
        </details>
        <a href={demo.source} target="_blank" rel="noopener noreferrer" className="mt-4 inline-block underline underline-offset-4 hover:text-red-300">View matching code on GitHub</a>
      </div>
    </section>
  )
}

// ============================================================
// portfolioData.js — Single source of truth for portfolio content
// ============================================================

export const personalInfo = {
  name: "Darshan M",
  firstName: "Darshan M",
  brandName: "Darshan M", // shown in the preloader, navbar and footer
  title: "Python Full Stack Developer",
  location: "Bengaluru, India",
  phone: "9535413282",
  emails: {
    primary: "darshan712871@gmail.com",
    secondary: "",
  },
  summary: "Passionate Python Full Stack Web Developer who believes in learning through hands-on experience and building real-world projects.",
  resumeUrl: "/Resume.PDF", // located inside /public
};

// TAP Academy — the academy you trained with. Used in the footer credit.
export const academy = {
  name: "TAP Academy",
  url: "https://thetapacademy.com/",
};

export const socialLinks = {
  github: "https://github.com/Darshan-88",
  linkedin: "https://www.linkedin.com/in/darshan-m-a3b780270/",
  instagram: "https://www.instagram.com/darshan._88/",
};

export const heroContent = {
  greeting: "Hi, I'm Darshan M",
  titleHighlight: "Python Full Stack Developer",
  subtitle: "Turning ideas into scalable, user-friendly web applications through clean code, modern architectures, and hands-on problem solving.",
  ctaPrimary: { text: "Try CareerAI", href: "#career-demo" },
  ctaSecondary: {
    text: "Contact Me",
    href: "mailto:darshan712871@gmail.com?subject=Hiring Inquiry – Portfolio&body=Hello,%0D%0A%0D%0AI came across your portfolio and would like to discuss an opportunity with you.%0D%0A%0D%0ABest Regards,",
  },
  ctaResume: { text: "Download Resume", href: "/Resume.PDF" },
};

export const aboutContent = {
  heading: "Hello!",
  bio: `Hi, my name is <span class="text-black text-xl font-black mx-1 tracking-wide uppercase">Darshan M</span>, a passionate Python Full Stack Web Developer based in Bengaluru, India. I specialize in building efficient, user-friendly, and impactful web applications, sharpening my skills through the placement training program at TAP Academy.`,
  techStack: ["Python", "FastAPI", "Flask", "React", "JavaScript", "Tailwind CSS", "SQLite"],
};

export const skillsContent = {
  badge: "My Process",
  heading: "Here's how I turn ideas into real-world products",
  description: "A methodical, engineering-driven approach to creating scalable, reliable web applications.",
  cards: [
    { number: "01", title: "Research", text: "Analyzing user requirements, core domain problems, and selecting optimal architecture and tools." },
    { number: "02", title: "Design", text: "Structuring clean database schemas, intuitive UI wireframes, and secure API contracts." },
    { number: "03", title: "Develop", text: "Writing robust backend APIs with FastAPI/Flask and crafting responsive frontends." },
    { number: "04", title: "Deploy", text: "Setting up CI/CD workflows, containerization, and monitoring reliable production deployments." },
  ],
  endText: "Ready to ship!",
};

export const technicalSkills = {
  categories: [
    {
      title: "Programming",
      skills: [{ name: "Python" }, { name: "JavaScript" }, { name: "SQL" }],
    },
    {
      title: "Web Development",
      skills: [{ name: "FastAPI" }, { name: "Flask" }, { name: "React" }, { name: "Tailwind CSS" }, { name: "HTML5 & CSS3" }],
    },
    {
      title: "Databases",
      skills: [{ name: "SQLite" }, { name: "PostgreSQL" }, { name: "MySQL" }],
    },
    {
      title: "Tools & Practices",
      skills: [{ name: "Git & GitHub" }, { name: "REST APIs" }, { name: "JWT Auth" }, { name: "Postman" }, { name: "VS Code" }],
    },
  ],
};

export const leadershipList = [
  {
    title: "Technical Project Lead – CareerAI",
    description: "Spearheaded the architecture and end-to-end development of the CareerAI platform, directing API integrations, database workflows, and deployment cycles.",
    role: "Lead Full-Stack Developer",
    badge: "Project Lead",
  },
  {
    title: "Peer Coding & Knowledge Sharing",
    description: "Actively collaborated with fellow students and developer peers at TAP Academy, conducting code reviews and troubleshooting Python and React challenges.",
    role: "Developer & Mentor",
    badge: "Community",
  },
];

export const internshipsList = [
  {
    organization: "TAP Academy",
    role: "Full Stack Developer Trainee",
    duration: "2024 - 2025",
    skills: [
      "Full-Stack Web Architecture",
      "RESTful API Design & Integration",
      "Database Modeling & Optimization",
      "Version Control & Modern Workflows",
    ],
    tech: ["Python", "FastAPI", "Flask", "React", "SQLite", "Git"],
  },
];

export const softSkillsList = [
  { name: "Problem Solving", icon: "🧩", desc: "Breaking down complex system challenges into modular, deliverable components." },
  { name: "Team Collaboration", icon: "🤝", desc: "Thriving in agile, cross-functional engineering teams with open communication." },
  { name: "Analytical Thinking", icon: "📈", desc: "Evaluating performance bottlenecks, edge cases, and architectural tradeoffs." },
  { name: "Adaptability", icon: "⚡", desc: "Quickly learning emerging frameworks, libraries, and full-stack paradigms." },
];

export const projects = [
  {
    id: "career-ai",
    number: "01",
    badge: "🚀 Flagship Project",
    title: "CareerAI – AI-Powered Job Intelligence Platform",
    description: "Built a full-stack web application for resume analysis, skill extraction, job-role matching, and personalized skill-gap insights, with secure JWT authentication and REST APIs.",
    techTags: ["Python", "FastAPI", "HTML", "CSS", "JavaScript", "JWT"],
    links: {
      github: "https://github.com/Darshan-88/Career-AI",
      demo: "https://career-ai-zeta-dusky.vercel.app/",
    },
    isFlagship: true,
  },
  {
    id: "explore-bengaluru",
    number: "02",
    badge: null,
    title: "Explore Bengaluru – Top 10 Places to Visit",
    description: "Developed a responsive travel guide web application showcasing Bengaluru's top tourist destinations, featuring interactive image sliders, category-based filtering, destination details, and Google Maps integration.",
    techTags: ["Python", "Flask", "HTML", "CSS", "JavaScript", "Google Maps"],
    links: {
      github: "https://github.com/Darshan-88/EXPLOREBENGLURU",
      demo: "https://top10bengaluru.vercel.app/",
    },
    isFlagship: false,
  },
  {
    id: "life-os",
    number: "03",
    badge: null,
    title: "Life OS – Personal Productivity & Life Management Platform",
    description: "Developed a full-stack personal productivity web application to manage daily tasks, expenses, habits, notes, and upcoming events with a rule-based AI-style personal assistant.",
    techTags: ["Python", "Flask", "SQLite", "HTML", "CSS", "JavaScript", "REST APIs"],
    links: {
      github: "https://github.com/Darshan-88",
      demo: "https://life-os-pi-sable.vercel.app/",
    },
    isFlagship: false,
  },
];

export const certificates = {
  featured: [],
  viewAllUrl: "https://www.linkedin.com/in/darshan-m-a3b780270/",
};

export const education = {
  degree: "B.E Information Science Engineering",
  institution: "Rajeev Institute of Technology, Hassan",
  cgpa: "2020 - 2024",
  graduation: "2024",
  twelfth: "",
  tenth: "",
};

export const footerContent = {
  taglines: ["Python Full Stack Developer", "Python · FastAPI · React", "Building scalable real-world web apps"],
  credential: "B.E Information Science Engineering",
  copyright: `© ${new Date().getFullYear()} Darshan M | Built with React`,
};

export const emailjsConfig = {
  serviceId: import.meta.env.VITE_EMAILJS_SERVICE_ID,
  templateId: import.meta.env.VITE_EMAILJS_TEMPLATE_ID,
  publicKey: import.meta.env.VITE_EMAILJS_PUBLIC_KEY,
};

export const careerDemo = {
  title: 'Try CareerAI',
  intro: 'Edit either sample, then compare the skills in the résumé with the job requirements. Try adding Docker to the job description.',
  resume: 'I built a FastAPI service in Python and wrote SQL queries to report on customer orders.',
  job: 'We are looking for a backend developer with Python, FastAPI and SQL experience.',
  source: 'https://github.com/Darshan-88/Career-AI/blob/0188bfe16ed991008a4a69d807d682b8ff191353/backend/app/ai/job_analyzer.py',
  architecture: ['JavaScript frontend', 'FastAPI backend', 'Résumé text extraction', 'Skill matching', 'Results in the frontend'],
  decision: 'The Python analyser checks a fixed vocabulary using word boundaries. That makes each match explainable and keeps Java from matching JavaScript. It can miss equivalent wording: “containerisation” alone does not count as Docker.',
  skills: ['python','java','javascript','typescript','html','css','react','node.js','fastapi','django','flask','sql','mysql','mongodb','firebase','git','github','docker','aws','machine learning','data science','pandas','numpy','tensorflow','pytorch','power bi','excel','communication','problem solving','dsa','oop','rest api'],
};
